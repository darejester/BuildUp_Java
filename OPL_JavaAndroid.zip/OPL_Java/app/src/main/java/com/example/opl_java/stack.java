package com.example.opl_java;
import java.io.Serializable;
import java.util.ArrayList;

public class stack implements Serializable
{
    private ArrayList<domino> m_stack = new ArrayList<domino>();

    public BuildUpController m_controller;

    //constructor
    public stack()
    {
        System.out.print("\nDEBUG: stack constructor\n\n");

        for (int i = 0; i < 12; i++)
        {
            m_stack.add(null);
        }
    }

    public void receiveBuildUpController(BuildUpController a_controller)
    {
        System.out.print("\nDEBUG: receiveBuildUpController() \n\n");

        m_controller = a_controller;
    }

    public ArrayList<domino> get_stack()
    {
        //return new ArrayList<domino>(m_stack);
        return m_stack;
    }

    public final void display_stack()
    {
        System.out.print("STACK:");
        System.out.print("\n");
        System.out.print(" 0   1   2   3   4   5\n");

        for (int i = 0; i < 12; i++)
        {
            if (i == 6)
            {
                System.out.print("\n");
            }
            m_stack.get(i).display_domino();
            System.out.print(" ");

        }
        System.out.print("\n");
        System.out.print(" 6   7   8   9   10  11\n ");
        System.out.print("\n");

        m_controller.updateStack(m_stack);

    }


}

