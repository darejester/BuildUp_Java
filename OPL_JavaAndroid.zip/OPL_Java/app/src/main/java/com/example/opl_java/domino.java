package com.example.opl_java;

import java.io.Serializable;

public class domino implements Serializable
{
    //left pip
    private int m_l_pips;
    //right pip
    private int m_r_pips;
    //color
    private char m_color;

    //constructor

    /**
     * constructor: takes in values for the left and right pips, as well as the color for the domino
     * @param a_l type: int, corresponds to the left pip number
     * @param a_r type: int, corresponds to the right pip number
     * @param a_color type: char, corresponds to the color value
     */
    public domino(int a_l, int a_r,char a_color)
    {
        System.out.print("\nDEBUG: domino constructor\n\n");


        this.m_l_pips = a_l;
        this.m_r_pips = a_r;
        this.m_color = a_color;
    }


    /**
     * returns the total number of pips (left pip + right pip)
     * @return returns an integer that corresponds to the total number of pips a domino has
     */
    public int total_pips()
    {
        return m_l_pips + m_r_pips;
    }

    /**
     * returns the left pip number
     * @return returns an integer that corresponds to the value of the left pip
     */
    public int display_l_pips()
    {
        return m_l_pips;
    }

    /**
     * returns the right pip number
     * @return returns an integer that corresponds to the vlaue of the right pip
     */
    public int display_r_pips()
    {
        return m_r_pips;
    }

    /**
     * returns the color of the domino
     * @return returns a character that corresponds to the color of the domino
     */
    public char display_color()
    {
        return m_color;
    }

    /**
     * returns the domino as a string
     * @return returns a string that has the color,left-pip, and right pip of the domino
     */
    public String display_domino()
    {
        String string = "";
        System.out.print(m_color);
        System.out.print(m_l_pips);
        System.out.print(m_r_pips);
        string += String.valueOf(display_color());
        string+= String.valueOf(display_l_pips());
        string += String.valueOf(display_r_pips());
//        return(String.valueOf(display_color()) + String.valueOf(display_l_pips()) + String.valueOf(display_r_pips()));
        return string;

    }


}

