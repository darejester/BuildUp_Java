package com.example.opl_java;

import java.io.Serializable;

public class domino implements Serializable
{
    //left pip
    private int m_l_pips;
    //right pip
    private int m_r_pips;
    //color
    private char m_color;

    //constructor
    public domino(int a_l, int a_r,char a_color)
    {
        System.out.print("\nDEBUG: domino constructor\n\n");


        this.m_l_pips = a_l;
        this.m_r_pips = a_r;
        this.m_color = a_color;
    }

    public int total_pips()
    {
        return m_l_pips + m_r_pips;
    }

    public int display_l_pips()
    {
        return m_l_pips;
    }

    public int display_r_pips()
    {
        return m_r_pips;
    }

    public char display_color()
    {
        return m_color;
    }

    public String display_domino()
    {
        String string = "";
        System.out.print(m_color);
        System.out.print(m_l_pips);
        System.out.print(m_r_pips);
        string += String.valueOf(display_color());
        string+= String.valueOf(display_l_pips());
        string += String.valueOf(display_r_pips());
//        return(String.valueOf(display_color()) + String.valueOf(display_l_pips()) + String.valueOf(display_r_pips()));
        return string;

    }


}

