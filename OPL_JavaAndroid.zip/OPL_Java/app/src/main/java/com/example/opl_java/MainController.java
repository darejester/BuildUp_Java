package com.example.opl_java;

import java.io.IOException;

public class MainController {

    public tournament m_tournament;

    public MainActivity m_mainActivity;


    //constructor

    /**
     * constructor initializer the m_mainActivity member
     * @param a_mainActivity type: MainActivity, corresponds to the reference of the main view
     */
    public MainController(MainActivity a_mainActivity)
    {
        System.out.print("\nDEBUG: MainController Constructor \n\n");

        //set view
        System.out.print("\nDEBUG: getting  MainActivity reference \n\n");
        m_mainActivity = a_mainActivity;
    }

    //calls model function to do stuff

    /**
     * creates a new tournament object and passes it a value of 0
     * @return returns a reference of the m_tournament
     */
    public tournament controller_start_tournament()
    {
        System.out.print("\nDEBUG: controller_start_tournament() \n\n");

        //call model function
        System.out.print("\nDEBUG: creating new tournament object \n\n");
        m_tournament = new tournament(0);

//        System.out.print("\nDEBUG: calling start_tournament() \n\n");
//        try
//        {
//            m_tournament.start_tournament();
//        }
//        catch (IOException e)
//        {
//            // Handle the exception here
//            System.out.print("\nDEBUG: IOException \n\n");
//        }

//        System.out.print("\nDEBUG: returning tournament reference \n\n");
        return m_tournament;
    }

    //calls model function to do stuff

    /**
     * creates a new tournament object and passes it a value of 1
     * @return returns a reference of the m_tournament
     */
    public tournament controller_resume_tournament()
    {
        System.out.print("\nDEBUG: controller_resume_tournament() \n\n");

        //call model function
        System.out.print("\nDEBUG: creating new tournament object \n\n");
        m_tournament = new tournament(1);

//        System.out.print("\nDEBUG: calling resume_tournament() \n\n");
//        m_tournament.resume_tournament();

//        System.out.print("\nDEBUG: returning tournament reference \n\n");
        return m_tournament;
    }

    /**
     * returns the reference for the m_tournament member
     * @return returns a tournament reference that corresponds to the tne m_tournament member
     */
    public tournament controller_get_tournament()
    {
        System.out.print("\nDEBUG: controller_get_tournament() \n\n");

        System.out.print("\nDEBUG: returning tournament reference \n\n");
        return m_tournament;
    }


}
