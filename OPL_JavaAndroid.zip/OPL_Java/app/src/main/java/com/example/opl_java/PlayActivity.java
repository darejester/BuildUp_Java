package com.example.opl_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.TextView;


public class PlayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        // Get a reference to the messageWindow
        TextView textView = findViewById(R.id.messageWindow);

        // Set the text of the messageWindow
        String text = "DEBUG: This is some sample text.\n";
        textView.setText(text);

        String moreText = "DEBUG: This is some more sample text. \n";
        int i = 0;
        while (i < 50) {
            // Append more text to the TextView

            textView.append(moreText);
            i++;
        }

    }
}