package com.example.opl_java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import android.content.Intent;
import java.io.Serializable;

import org.w3c.dom.Text;

import java.util.Random;

public class PlayActivity extends AppCompatActivity {
    //message window to display text in
    Context m_context;
    public TextView m_messageWindow;
    public Button m_testButton;

    public Button[] botBone;
    public Button[] botHand;
    public Button[] stack;
    public Button[] humanHand;
    public Button[] humanBone;
    public Button getHelp;

    public Button continueGame;

    public Button exitGame;
    int loc1;
    int loc2;

    //controller
    BuildUpController m_controller;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        loc1 = -1;
        loc2 = -1;

        // Get a reference to the messageWindow
        m_messageWindow = findViewById(R.id.messageWindow);
        //get a reference for the button
        m_testButton = findViewById(R.id.botBone0);

        //get an array of references for BotBone
        botBone = new Button[22];
        for (int i = 0; i < 22; i++) {
            int id = getResources().getIdentifier("botBone" + i, "id", getPackageName());
            botBone[i] = findViewById(id);
            botBone[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(botBone[i]) +"\n");
        }

        //get an array of references for botHand
        botHand = new Button[6];
        for (int i = 0; i < 6; i++) {
            int id = getResources().getIdentifier("botHand" + i, "id", getPackageName());
            botHand[i] = findViewById(id);
            botHand[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(botHand[i]) +"\n");
        }

        //get an array of references for stack
        stack = new Button[12];
        for (int i = 0; i < 12; i++) {
            int id = getResources().getIdentifier("stack" + i, "id", getPackageName());
            stack[i] = findViewById(id);
            stack[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(stack[i]) +"\n");
        }

        //get an array of references for humanHand
        humanHand = new Button[6];
        for (int i = 0; i < 6; i++) {
            int id = getResources().getIdentifier("humanHand" + i, "id", getPackageName());
            humanHand[i] = findViewById(id);
            humanHand[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(humanHand[i]) +"\n");
        }

        //get an array of references for humanBone
        humanBone = new Button[22];
        for (int i = 0; i < 22; i++) {
            int id = getResources().getIdentifier("humanBone" + i, "id", getPackageName());
            humanBone[i] = findViewById(id);
            humanBone[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(humanBone[i]) +"\n");
        }

        //get get help button
        getHelp = findViewById(R.id.getHelp);

        continueGame = findViewById(R.id.continueGame);

        exitGame = findViewById(R.id.exitGame);

        Context m_context = this;




        //load in intent
        System.out.print("\nDEBUG: getting MainActivity Intent \n\n");
        Intent intent = getIntent();
        System.out.print("\nDEBUG: getting tournament from Intent \n\n");
        System.out.print("\nDEBUG: creating BuildUpController object \n\n");
        m_controller = new BuildUpController((tournament) intent.getSerializableExtra("model"), this,m_context);


//        // add text of the messageWindow
//        String text = "DEBUG: This is some sample text.\n";
//        m_messageWindow.append(text);

//        String moreText = "DEBUG: This is some more sample text. \n";
//        int i = 0;
//        while (i < 50) {
//            // Append more text to the TextView
//
//            m_messageWindow.append(moreText);
//            i++;
//        }


        //when testButton is clicked
        stack[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (loc1 != -1)
                {
                    loc2 = 0;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }
                //calls controller to tell it that a button is clicked and something needs to happen

            }
        });

        stack[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 1;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 2;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 3;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 4;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 5;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[6].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 6;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[7].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 7;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[8].setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 8;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[9].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 9;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[10].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 10;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        stack[11].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                if (loc1 != -1)
                {
                    loc2 = 11;
                    if (m_controller.check_legal(loc1,loc2))
                    {
                        m_controller.place(loc1,loc2);
                    }
                }
                else
                {
                    m_messageWindow.append("select a domino from your hand first\n");
                }

            }
        });

        humanHand[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loc1 = 0;
                //calls controller to tell it that a button is clicked and something needs to happen

            }
        });

        humanHand[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loc1 = 1;
                //calls controller to tell it that a button is clicked and something needs to happen

            }
        });

        humanHand[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loc1 = 2;
                //calls controller to tell it that a button is clicked and something needs to happen

            }
        });

        humanHand[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loc1 = 3;
                //calls controller to tell it that a button is clicked and something needs to happen

            }
        });

        humanHand[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loc1 = 4;
                //calls controller to tell it that a button is clicked and something needs to happen

            }
        });

        humanHand[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loc1 = 5;
                //calls controller to tell it that a button is clicked and something needs to happen

            }
        });

        getHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                m_controller.help();
            }
        });

        continueGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                m_controller.gameContinue();
            }
        });

        exitGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                m_controller.exitGame();
            }
        });

    }
}