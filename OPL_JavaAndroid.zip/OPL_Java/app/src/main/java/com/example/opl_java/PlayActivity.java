package com.example.opl_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import android.content.Intent;
import java.io.Serializable;

import org.w3c.dom.Text;

import java.util.Random;

public class PlayActivity extends AppCompatActivity {
    //message window to display text in
    public TextView m_messageWindow;
    public Button m_testButton;

    public Button[] botBone;
    public Button[] botHand;
    public Button[] stack;
    public Button[] humanHand;
    public Button[] humanBone;

    //controller
    BuildUpController m_controller;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);


        // Get a reference to the messageWindow
        m_messageWindow = findViewById(R.id.messageWindow);
        //get a reference for the button
        m_testButton = findViewById(R.id.botBone0);

        //get an array of references for BotBone
        botBone = new Button[22];
        for (int i = 0; i < 22; i++) {
            int id = getResources().getIdentifier("botBone" + i, "id", getPackageName());
            botBone[i] = findViewById(id);
            botBone[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(botBone[i]) +"\n");
        }

        //get an array of references for botHand
        botHand = new Button[6];
        for (int i = 0; i < 6; i++) {
            int id = getResources().getIdentifier("botHand" + i, "id", getPackageName());
            botHand[i] = findViewById(id);
            botHand[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(botHand[i]) +"\n");
        }

        //get an array of references for stack
        stack = new Button[12];
        for (int i = 0; i < 12; i++) {
            int id = getResources().getIdentifier("stack" + i, "id", getPackageName());
            stack[i] = findViewById(id);
            stack[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(stack[i]) +"\n");
        }

        //get an array of references for humanHand
        humanHand = new Button[6];
        for (int i = 0; i < 6; i++) {
            int id = getResources().getIdentifier("humanHand" + i, "id", getPackageName());
            humanHand[i] = findViewById(id);
            humanHand[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(humanHand[i]) +"\n");
        }

        //get an array of references for humanBone
        humanBone = new Button[22];
        for (int i = 0; i < 22; i++) {
            int id = getResources().getIdentifier("humanBone" + i, "id", getPackageName());
            humanBone[i] = findViewById(id);
            humanBone[i].setVisibility(View.GONE);
//            m_messageWindow.append(String.valueOf(humanBone[i]) +"\n");
        }




        //load in intent
        System.out.print("\nDEBUG: getting MainActivity Intent \n\n");
        Intent intent = getIntent();
        System.out.print("\nDEBUG: getting tournament from Intent \n\n");
        System.out.print("\nDEBUG: creating BuildUpController object \n\n");
        m_controller = new BuildUpController((tournament) intent.getSerializableExtra("model"), this);


        // add text of the messageWindow
        String text = "DEBUG: This is some sample text.\n";
        m_messageWindow.append(text);

//        String moreText = "DEBUG: This is some more sample text. \n";
//        int i = 0;
//        while (i < 50) {
//            // Append more text to the TextView
//
//            m_messageWindow.append(moreText);
//            i++;
//        }


        //when testButton is clicked
        botHand[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //calls controller to tell it that a button is clicked and something needs to happen
                m_messageWindow.append(String.valueOf(botHand[0]) +"\n");

            }
        });

    }
}