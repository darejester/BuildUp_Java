package com.example.opl_java;

import java.io.IOException;

import android.content.Context;
import android.widget.Button;
import android.view.View;
import android.graphics.Color;
import java.util.ArrayList;

public class BuildUpController {
    //model
//    private BuildUpModel m_model;
    private tournament m_tournament;
    //view
    private PlayActivity m_playActivity;

    public Context m_context;


    //constructor

    /**
     * constructor: gets references for m_playActivity, m_tournament, and a_context. This is also responsible for calling either the resume or start functions of the tournament object
     * @param a_tournament type: tournament, this is the reference to the model
     * @param a_playActivity type: PlayActivity, this is the reference to the view
     * @param a_context type: Context, this is the reference to the object that is going to allow serialization
     */
    public BuildUpController(tournament a_tournament ,PlayActivity a_playActivity,Context a_context)
    {
        System.out.print("\nDEBUG: BuildUpController Constructor \n\n");

        //set view
        System.out.print("\nDEBUG: getting PlayActivity reference \n\n");
        m_playActivity = a_playActivity;
        System.out.print("\nDEBUG: getting tournament reference \n\n");
        m_tournament = a_tournament;
        m_context = a_context;

        System.out.print("\nDEBUG: give tournament the BuildUpController Reference \n\n");
        try
        {

            m_tournament.receiveBuildUpController(this);
        }
        catch (IOException e)
        {
            // Handle the exception here
            System.out.print("\nDEBUG: IOException \n\n");
        }

        System.out.print("\nDEBUG: choose if resuming or starting new \n\n");
        if(m_tournament.m_resumeOrStart == 0)
        {
            try
            {
                m_playActivity.m_messageWindow.append("DEBUG: start_tournament() \n");
                m_tournament.start_tournament();
            }
            catch (IOException e)
            {
                // Handle the exception here
                System.out.print("\nDEBUG: IOException \n\n");
            }
        }
        else if (m_tournament.m_resumeOrStart == 1)
        {
            m_playActivity.m_messageWindow.append("DEBUG: resume_tournament() \n");
            m_tournament.resume_tournament();
        }

    }



    //gets result from model and display it in the message window of view

    /**
     * this is responsible for appending a string to the scrollview window of the view
     * @param test type: String, this is the string that is going to be appended to the scrollview window
     */
    public void appendToScrollView(String test)
    {
        //messageWindow.append(String.valueOf(testInt));
        m_playActivity.m_messageWindow.append(String.valueOf(test));
    }

    /**
     * this is responsible for updating the UI for the bot's boneyard
     * @param a_BotBone type: ArrayList, this corresponds to the bot's boneyard
     */
    public void updateBotBone(ArrayList<domino> a_BotBone)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.botBone.length; i++)
        {
            if (i < a_BotBone.size())
            {
                m_playActivity.botBone[i].setText(String.valueOf(a_BotBone.get(i).display_l_pips()) + "\n" + a_BotBone.get(i).display_r_pips());
                m_playActivity.botBone[i].setVisibility(View.VISIBLE);
                m_playActivity.botBone[i].setTextColor(Color.BLACK);
                m_playActivity.botBone[i].setBackgroundColor(Color.YELLOW);
                m_playActivity.botBone[i].setEnabled(false);
            }
            else
            {
                m_playActivity.botBone[i].setText("");
                m_playActivity.botBone[i].setVisibility(View.INVISIBLE);
            }

        }
    }

    /**
     * this is responsible for updating the UI for the bot's hand
     * @param a_BotHand type: ArraList, this corresponds to the bot's hand
     */
    public void updateBotHand(ArrayList<domino> a_BotHand)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.botHand.length; i++)
        {
            if (i < a_BotHand.size())
            {
                m_playActivity.botHand[i].setText(String.valueOf(a_BotHand.get(i).display_l_pips()) + "\n" + a_BotHand.get(i).display_r_pips());
                m_playActivity.botHand[i].setVisibility(View.VISIBLE);
                m_playActivity.botHand[i].setTextColor(Color.BLACK);
                m_playActivity.botHand[i].setBackgroundColor(Color.YELLOW);
                m_playActivity.botHand[i].setEnabled(false);
            }
            else
            {
                m_playActivity.botHand[i].setText("");
                m_playActivity.botHand[i].setVisibility(View.INVISIBLE);
            }

        }
    }

    /**
     * this is responsible for updating the UI for the 12 stacks
     * @param a_Stack type: ArrayList, this corresponds to the 12 stacks
     */
    public void updateStack(ArrayList<domino> a_Stack)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.stack.length; i++)
        {
            if (i < a_Stack.size())
            {
                m_playActivity.stack[i].setText(String.valueOf(a_Stack.get(i).display_l_pips()) + "\n" + a_Stack.get(i).display_r_pips());
                m_playActivity.stack[i].setVisibility(View.VISIBLE);

                if(a_Stack.get(i).display_color() == 'W')
                {
                    m_playActivity.stack[i].setTextColor(Color.BLACK);
                    m_playActivity.stack[i].setBackgroundColor(Color.YELLOW);
                }
                else if (a_Stack.get(i).display_color() == 'B')
                {
                    m_playActivity.stack[i].setBackgroundColor(Color.BLACK);
                    m_playActivity.stack[i].setTextColor(Color.WHITE);
                }
            }
            else
            {
                m_playActivity.stack[i].setText("");
                m_playActivity.stack[i].setVisibility(View.INVISIBLE);
            }

        }
    }

    /**
     * this is responsible for updating the UI for the human's hand
     * @param a_HumanHand type: ArraList, this corresponds to the human's hand
     */
    public void updateHumanHand(ArrayList<domino> a_HumanHand)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.humanHand.length; i++)
        {
            if (i < a_HumanHand.size())
            {
                m_playActivity.humanHand[i].setText(String.valueOf(a_HumanHand.get(i).display_l_pips()) + "\n" + a_HumanHand.get(i).display_r_pips());
                m_playActivity.humanHand[i].setVisibility(View.VISIBLE);
                m_playActivity.humanHand[i].setBackgroundColor(Color.BLACK);
            }
            else
            {
                m_playActivity.humanHand[i].setText("");
                m_playActivity.humanHand[i].setVisibility(View.INVISIBLE);
            }

        }
    }

    /**
     * this is responsible for updating the UI for the human's boneyard
     * @param a_HumanBone type: ArrayList, this corresponds to the human's boneyard
     */
    public void updateHumanBone(ArrayList<domino> a_HumanBone)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.humanBone.length; i++)
        {
            if (i < a_HumanBone.size())
            {
                m_playActivity.humanBone[i].setText(String.valueOf(a_HumanBone.get(i).display_l_pips()) + "\n" + a_HumanBone.get(i).display_r_pips());
                m_playActivity.humanBone[i].setVisibility(View.VISIBLE);
                m_playActivity.humanBone[i].setBackgroundColor(Color.BLACK);
                m_playActivity.humanBone[i].setTextColor(Color.WHITE);
                m_playActivity.humanBone[i].setEnabled(false);
            }
            else
            {
                m_playActivity.humanBone[i].setText("");
                m_playActivity.humanBone[i].setVisibility(View.INVISIBLE);
            }

        }
    }

    /**
     * this is responsible for checking whether the dominos that the player clicked is a legal move
     * @param a_loc1 type: int, this corresponds to the location of the domino in the player's hand
     * @param a_loc2 type: int, this corresponds to the location of the domino in the stacks
     * @return returns a boolean value that corresponds to whether the move is a legal move
     */
    public boolean check_legal(int a_loc1, int a_loc2)
    {
        return m_tournament.get_player().check_legality(m_tournament.get_player().get_hand(),m_tournament.get_stack().get_stack(),a_loc1,a_loc2);
    }

    /**
     * this is responsible for doing the procedure needed for the player to make the move by calling functions of the model
     * @param a_loc1 type: int, this corresponds to the location in the player's hand
     * @param a_loc2 type: int, this corresponds to the location in the stacks
     */
    public void place(int a_loc1, int a_loc2)
    {
        m_tournament.get_player().place(m_tournament.get_stack(),a_loc1, a_loc2);
        m_tournament.get_round().next_turn();
        m_tournament.play();

    }

    /**
     * this is responsible for doing the procedure needed to execute the get help feature of the game when the get help button is pressed
     */
    public void help()
    {
        m_tournament.get_player().get_help(m_tournament.get_player().get_hand(),m_tournament.get_stack().get_stack(), m_tournament.get_bot());
        m_tournament.get_round().next_turn();
        m_tournament.play();

    }

    /**
     * this is responsible for doing the procedure needed to execute the save feature of the game when the save button is pressed
     */
    public void save()
    {
        m_playActivity.continueGame.setVisibility(View.INVISIBLE);
        m_playActivity.continueGame.setEnabled(false);
        m_playActivity.exitGame.setVisibility(View.INVISIBLE);
        m_playActivity.exitGame.setEnabled(false);
        m_playActivity.getHelp.setVisibility(View.INVISIBLE);
        m_playActivity.getHelp.setEnabled(false);
        m_playActivity.saveGame.setVisibility(View.INVISIBLE);
        m_playActivity.saveGame.setEnabled(false);


        try
        {

            m_tournament.save_game();
        }
        catch (IOException e)
        {
            // Handle the exception here
            System.out.print("\nDEBUG: IOException \n\n");
        }

    }

    /**
     * this is responsible for handling the visibility of the utility buttons
     */
    public void updateUtilityButtons( )
    {

        if (m_playActivity.continueGame.getVisibility() == View.VISIBLE) {
            // Button is visible
            m_playActivity.continueGame.setVisibility(View.INVISIBLE);
            m_playActivity.continueGame.setEnabled(false);
            m_playActivity.exitGame.setVisibility(View.INVISIBLE);
            m_playActivity.exitGame.setEnabled(false);
            m_playActivity.getHelp.setVisibility(View.VISIBLE);
            m_playActivity.getHelp.setEnabled(true);
            m_playActivity.saveGame.setVisibility(View.VISIBLE);
            m_playActivity.saveGame.setEnabled(true);
        } else {
            // Button is not visible
            m_playActivity.continueGame.setVisibility(View.VISIBLE);
            m_playActivity.continueGame.setEnabled(true);
            m_playActivity.exitGame.setVisibility(View.VISIBLE);
            m_playActivity.exitGame.setEnabled(true);
            m_playActivity.getHelp.setVisibility(View.INVISIBLE);
            m_playActivity.getHelp.setEnabled(false);
            m_playActivity.saveGame.setVisibility(View.INVISIBLE);
            m_playActivity.saveGame.setEnabled(false);

        }


    }


    /**
     * this is responsible for doing the procedure needed to continue onto the next round when the continue button is pressed
     */
    public void gameContinue()
    {
        try
        {

            m_tournament.resetGame();
        }
        catch (IOException e)
        {
            // Handle the exception here
            System.out.print("\nDEBUG: IOException \n\n");
        }

    }

    /**
     * this is responsible for doing the procedure needed to exit the tournament when the exit button is pressed
     */
    public void exitGame()
    {
        m_tournament.exitGame();

        m_playActivity.continueGame.setVisibility(View.INVISIBLE);
        m_playActivity.continueGame.setEnabled(false);
        m_playActivity.exitGame.setVisibility(View.INVISIBLE);
        m_playActivity.exitGame.setEnabled(false);
        m_playActivity.getHelp.setVisibility(View.INVISIBLE);
        m_playActivity.getHelp.setEnabled(false);

    }

    /**
     * returns the reference of the m_context object
     * @return returns the reference of the m_context object
     */
    public Context get_context()
    {
        return m_context;
    }

}
