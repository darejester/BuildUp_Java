package com.example.opl_java;

import java.io.IOException;

public class BuildUpController {
    //model
//    private BuildUpModel m_model;
    private tournament m_tournament;
    //view
    private PlayActivity m_playActivity;



    //constructor
    public BuildUpController(tournament a_tournament ,PlayActivity a_playActivity)
    {
        System.out.print("\nDEBUG: BuildUpController Constructor \n\n");

        //set view
        System.out.print("\nDEBUG: getting PlayActivity reference \n\n");
        m_playActivity = a_playActivity;
        System.out.print("\nDEBUG: getting tournament reference \n\n");
        m_tournament = a_tournament;
    }




    //gets result from model and display it in the message window of view
    public void getResultsFromModel(String test)
    {
        //messageWindow.append(String.valueOf(testInt));
        m_playActivity.m_messageWindow.append(String.valueOf(test));
    }

}
