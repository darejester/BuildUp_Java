package com.example.opl_java;
import java.util.ArrayList;

public abstract class player
{
    public abstract ArrayList<domino> get_hand();
    public abstract ArrayList<domino> get_boneyard();
    public abstract char get_id();
    public abstract void draw();
    public abstract boolean is_hand_empty();
    public abstract void display_hand();
    public abstract void display_boneyard();
    public abstract void place(stack a_stack, int a_loc1, int a_loc2);
    public abstract void fill_stack(ArrayList<domino> a_stack);
    public abstract void player_play(stack a_stack, player a_bot);
    public abstract void strategy(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp, int[] a_loc1, int[] a_loc2);
    public abstract boolean check_playable(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp);
    public abstract boolean check_legality(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp, int a_loc1, int a_loc2);

}
