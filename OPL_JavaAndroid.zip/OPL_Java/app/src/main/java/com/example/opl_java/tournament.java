package com.example.opl_java;

import java.io.IOException;
import java.io.Serializable;

public class tournament implements Serializable {
    //stack holder
    private stack m_stack;
    //player holder
    private human m_human;
    private bot m_bot;
    //turn holder
    private player[] m_turn_order;
    //score board holder(for whole tournament)
    private int[] m_scoreboard = new int[2];
    // holds number of rounds
    private int m_game_round_counter;
    // holds tournament scoreboard
    private int[] m_tournament_scoreboard = new int[2];







    //constructor
    public tournament() {
        System.out.print("\nDEBUG: tournament constructor \n\n");

        m_scoreboard[1] = 0;
        m_game_round_counter = 0;
        m_stack = new stack();
        m_stack.get_stack().clear();
        m_bot = new bot();
        m_bot.fill_stack(m_stack.get_stack());
        m_human = new human();
        m_human.fill_stack(m_stack.get_stack());
        m_turn_order = new player[2];
        m_turn_order[0] = null;
        m_turn_order[1] = null;
        m_tournament_scoreboard[0] = 0;
        m_tournament_scoreboard[1] = 0;

    }

    public void start_tournament() throws IOException
    {
        System.out.print("\nDEBUG: start_tournament() \n\n");
    }

    public void resume_tournament()
    {
        System.out.print("\nDEBUG: resume_tournament() \n\n");
    }

}
