package com.example.opl_java;

import android.os.Build;

import java.io.IOException;
import java.io.Serializable;

public class tournament implements Serializable {
    //stack holder
    private stack m_stack;
    //player holder
    private human m_human;
    private bot m_bot;
    //turn holder
    private player[] m_turn_order;
    //round holder
    private game_round m_round;
    //score board holder(for whole tournament)
    private int[] m_scoreboard = new int[2];;
    // holds number of rounds
    private int m_game_round_counter;
    // holds tournament scoreboard
    private int[] m_tournament_scoreboard = new int[2];



    //holder for an integer that's going to represent if player wants to (1)resume or (0)start new or (-1) if just continuing onto next tournament
    public int m_resumeOrStart;
    public BuildUpController m_controller;






    //constructor
    public tournament(int a_resumeOrStart) {
        System.out.print("\nDEBUG: tournament constructor \n\n");

        m_resumeOrStart = a_resumeOrStart;

        m_scoreboard[1] = 0;
        m_game_round_counter = 0;
        m_stack = new stack();
        m_stack.get_stack().clear();
        m_round = null;
        m_bot = new bot();
        m_bot.fill_stack(m_stack.get_stack());
        m_human = new human();
        m_human.fill_stack(m_stack.get_stack());
        m_turn_order = new player[2];
        m_turn_order[0] = null;
        m_turn_order[1] = null;
        m_tournament_scoreboard[0] = 0;
        m_tournament_scoreboard[1] = 0;

    }

    public void receiveBuildUpController(BuildUpController a_controller) throws IOException
    {
        System.out.print("\nDEBUG: receiveBuildUpController() \n\n");

        m_controller = a_controller;

        m_bot.receiveBuildUpController(m_controller);
        m_human.receiveBuildUpController(m_controller);
        m_stack.receiveBuildUpController(m_controller);
    }

    public final tournament get_tournament()
    {
        return this;
    }

    public player get_player()
    {
        return m_human;
    }

    public player get_bot()
    {
        return m_bot;
    }

    public game_round get_round()
    {
        return m_round;
    }

    public stack get_stack()
    {
        return m_stack;
    }

    public void start_tournament() throws IOException
    {
        System.out.print("\nDEBUG: start_tournament() \n\n");
//        m_controller.appendToScrollView(m_bot.display_boneyard());

        int continue_game = 1;

        //initialize new round
        m_round = new game_round();
        m_round.receiveBuildUpController(m_controller);

        if (m_human.get_boneyard().size() == 22)
        {
            m_round.first_pick(m_human, m_bot, m_turn_order, m_stack.get_stack());
        }

        String scoreboardString = "ROUND SCOREBOARD\n" +
                "B : " + m_scoreboard[0] + "\n" +
                "W : " + m_scoreboard[1] + "\n" +
                "TOURNAMENT SCOREBOARD\n" +
                "B: " + m_tournament_scoreboard[0] + "\n" +
                "W: " + m_tournament_scoreboard[1] + "\n";
        m_controller.appendToScrollView(scoreboardString);

//        m_bot.display_boneyard();

        play();






    }

    public void play()
    {
        m_round.round_play(m_human, m_bot, m_stack, m_turn_order, m_scoreboard);
    }

    public void resume_tournament()
    {
        System.out.print("\nDEBUG: resume_tournament() \n\n");
    }

}
