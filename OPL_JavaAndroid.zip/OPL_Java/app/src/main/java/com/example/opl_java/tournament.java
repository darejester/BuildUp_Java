package com.example.opl_java;

import android.content.Context;
import android.os.Build;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Scanner;

public class tournament implements Serializable {
    //stack holder
    private stack m_stack;
    //player holder
    private human m_human;
    private bot m_bot;
    //turn holder
    private player[] m_turn_order;
    //round holder
    private game_round m_round;
    //score board holder(for whole tournament)
    private int[] m_scoreboard = new int[2];;
    // holds number of rounds
    private int m_game_round_counter;
    // holds tournament scoreboard
    private int[] m_tournament_scoreboard = new int[2];



    //holder for an integer that's going to represent if player wants to (1)resume or (0)start new or (-1) if just continuing onto next tournament
    public int m_resumeOrStart;
    public BuildUpController m_controller;

    public Context get_context;






    //constructor
    public tournament(int a_resumeOrStart) {
        System.out.print("\nDEBUG: tournament constructor \n\n");

        m_resumeOrStart = a_resumeOrStart;

        m_scoreboard[1] = 0;
        m_game_round_counter = 0;
        m_stack = new stack();
        m_stack.get_stack().clear();
        m_round = null;
        m_bot = new bot();
        m_bot.fill_stack(m_stack.get_stack());
        m_human = new human();
        m_human.fill_stack(m_stack.get_stack());
        m_turn_order = new player[2];
        m_turn_order[0] = null;
        m_turn_order[1] = null;
        m_tournament_scoreboard[0] = 0;
        m_tournament_scoreboard[1] = 0;

    }

    public void receiveBuildUpController(BuildUpController a_controller) throws IOException
    {
        System.out.print("\nDEBUG: receiveBuildUpController() \n\n");

        m_controller = a_controller;

        m_bot.receiveBuildUpController(m_controller);
        m_human.receiveBuildUpController(m_controller);
        m_stack.receiveBuildUpController(m_controller);
    }

    public void resetGame( ) throws IOException
    {
        System.out.print("\nDEBUG: resetGame() \n\n");

        m_stack.get_stack().clear();
        m_bot = new bot();
        m_bot.fill_stack(m_stack.get_stack());
        m_human = new human();
        m_human.fill_stack(m_stack.get_stack());
        m_turn_order[0] = null;
        m_turn_order[1] = null;
        m_scoreboard[0] = 0;
        m_scoreboard[1] = 0;

        m_bot.receiveBuildUpController(m_controller);
        m_human.receiveBuildUpController(m_controller);
        m_stack.receiveBuildUpController(m_controller);

        start_tournament();
    }

    public void exitGame( )
    {
        System.out.print("\nDEBUG: exitGame() \n\n");
        String message= "";

        if ((m_tournament_scoreboard[0] > m_tournament_scoreboard[1]))
        {
            message = "WINNER: HUMAN!\n";
            m_controller.appendToScrollView(message);
        }
        else if (m_tournament_scoreboard[0] < m_tournament_scoreboard[1])
        {
            message = "WINNER: BOT!\n";
            m_controller.appendToScrollView(message);
        }
        else
        {
            message = "DRAW!\n";
            m_controller.appendToScrollView(message);
        }
    }

    public final tournament get_tournament()
    {
        return this;
    }

    public human get_player()
    {
        return m_human;
    }

    public player get_bot()
    {
        return m_bot;
    }

    public game_round get_round()
    {
        return m_round;
    }

    public stack get_stack()
    {
        return m_stack;
    }

    public void start_tournament() throws IOException
    {
        System.out.print("\nDEBUG: start_tournament() \n\n");
        String message = "";

        if (m_human.get_boneyard().isEmpty())
        {
            //update tournament scoreboard
            if (m_scoreboard[0] > m_scoreboard[1])
            {
                m_tournament_scoreboard[0]++;
            }
            else if (m_scoreboard[0] < m_scoreboard[1])
            {
                m_tournament_scoreboard[1]++;
            }
            else if (m_scoreboard[0] == m_scoreboard[1])
            {
                m_tournament_scoreboard[0]++;
                m_tournament_scoreboard[1]++;
            }

            message = "End of Round Scores: "
                    + "\nB : "
                    + m_scoreboard[0]
                    + "\nW : "
                    + m_scoreboard[1]
                    + "\n";

            m_controller.appendToScrollView(message);

            m_controller.updateUtilityButtons();


        }
        else
        {
            //initialize new round
            m_round = new game_round();
            m_round.receiveBuildUpController(m_controller);
            m_round.receiveTournament(this);


            if (m_human.get_boneyard().size() == 22)
            {
                m_round.first_pick(m_human, m_bot, m_turn_order, m_stack.get_stack());

                m_controller.updateUtilityButtons();

            }


            String scoreboardString = "ROUND SCOREBOARD\n" +
                    "B : " + m_scoreboard[0] + "\n" +
                    "W : " + m_scoreboard[1] + "\n" +
                    "TOURNAMENT SCOREBOARD\n" +
                    "B: " + m_tournament_scoreboard[0] + "\n" +
                    "W: " + m_tournament_scoreboard[1] + "\n";
            m_controller.appendToScrollView(scoreboardString);


            if (m_turn_order[0].get_hand().isEmpty() && m_turn_order[1].get_hand().isEmpty())
            {
                m_turn_order[0].draw();
                m_turn_order[1].draw();
            }


            play();
        }













    }

    public void play()
    {
        //check if either hand has a playable domino
        if(m_turn_order[0].check_playable(m_turn_order[0].get_hand(), m_stack.get_stack()) || m_turn_order[1].check_playable(m_turn_order[1].get_hand(), m_stack.get_stack()))
        {
//            m_round.display_turn(m_turn_order);
            m_bot.display_boneyard();
            m_bot.display_hand();
            m_stack.display_stack();
            m_human.display_hand();
            m_human.display_boneyard();

            m_round.round_play(m_human, m_bot, m_stack, m_turn_order, m_scoreboard);
        }
        else
        {
            m_controller.appendToScrollView("Both players have no more moves. ROUND END.\n");
            //score
            m_round.score(m_stack, m_turn_order, m_scoreboard);
            //clear hands
            for (player x : m_turn_order)
            {
                x.get_hand().clear();
            }

            try
            {
                start_tournament();
            }
            catch (IOException e)
            {
                // Handle the exception here
                System.out.print("\nDEBUG: IOException \n\n");
            }
        }
    }

    public void resume_tournament()
    {
        System.out.print("\nDEBUG: resume_tournament() \n\n");

        // clear out stack
        m_stack.get_stack().clear();

        // clear out player infos
        m_human.get_hand().clear();
        m_human.get_boneyard().clear();
        m_bot.get_hand().clear();
        m_bot.get_boneyard().clear();

        try {
//            System.out.println(System.getProperty("user.dir"));
//            FileInputStream file = new FileInputStream("com.example.opl_java/OPLsaveFile.txt");
//            BufferedReader br = new BufferedReader(new InputStreamReader(file));

//            File file = new File(getFilesDir(), "OPLsaveFile.txt");
//            FileInputStream fileInputStream = new FileInputStream(file);
//            BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream));

//            InputStream inputStream = getAssets().open("OPLsaveFile.txt");
//            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
//            BufferedReader br = new BufferedReader(inputStreamReader);

            InputStream inputStream = m_controller.get_context().getAssets().open("OPLsaveFile.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));

            ArrayList<String> divided_line = new ArrayList<String>();
            String line;

            // divide line into a vector
            while ((line = br.readLine()) != null) {
                divided_line.add(line);
            }

            // read in stacks
            read_to_stack(divided_line.get(1));
            read_to_stack(divided_line.get(8));

            // read in player infos
            read_to_player(divided_line.get(2), divided_line.get(3), divided_line.get(9), divided_line.get(10));

            // read in scores
            read_to_score(divided_line.get(4), divided_line.get(11), divided_line.get(5), divided_line.get(12));

            // read in turn
            read_in_turn(divided_line.get(14));

//            file.close(); // Close the file when you're done

            m_controller.updateUtilityButtons();

            // start tournament where it left off
            start_tournament();
        } catch (IOException e) {
            System.out.println("Unable to open file");
        }
    }

    public void read_to_stack(String a_temp) {
        String[] words = a_temp.split(" ");
        for (String word : words) {
            if (word.equals("Stacks:")) {
                continue;
            }

            if (word.length() >= 3 && Character.isDigit(word.charAt(1)) && Character.isDigit(word.charAt(2))) {
                m_stack.get_stack().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
            }
            else
            {
                // handle error or skip this line
            }
            //m_stack.get_stack().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }
    }

    void read_to_player(String a_temp1, String a_temp2, String a_temp3, String a_temp4) {
        //1 = bot boneyard, 2 = bot hand, 3 = human boneyard, 4 = human hand
        ArrayList<domino> a_temp_hand = new ArrayList<>();
        ArrayList<domino> a_temp_boneyard = new ArrayList<>();
        Scanner iss1 = new Scanner(a_temp1);
        Scanner iss2 = new Scanner(a_temp2);
        Scanner iss3 = new Scanner(a_temp3);
        Scanner iss4 = new Scanner(a_temp4);

        String word;

        //bot
        while (iss1.hasNext()) {
            word = iss1.next();
            if (word.equals("Boneyard:")) {
                continue;
            }
            m_bot.get_boneyard().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }
        while (iss2.hasNext()) {
            word = iss2.next();
            if (word.equals("Hand:")) {
                continue;
            }
            m_bot.get_hand().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }

        //human
        while (iss3.hasNext()) {
            word = iss3.next();
            if (word.equals("Boneyard:")) {
                continue;
            }
            m_human.get_boneyard().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }
        while (iss4.hasNext()) {
            word = iss4.next();
            if (word.equals("Hand:")) {
                continue;
            }
            m_human.get_hand().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }
    }

    public void read_to_score(String a_temp1, String a_temp2, String a_temp3, String a_temp4) {
        Scanner scanner1 = new Scanner(a_temp1);
        Scanner scanner2 = new Scanner(a_temp2);
        Scanner scanner3 = new Scanner(a_temp3);
        Scanner scanner4 = new Scanner(a_temp4);

        String word;
        // bot
        while (scanner1.hasNext()) {
            word = scanner1.next();
            if (word.equals("Score:")) {
                continue;
            }
            m_scoreboard[1] = Integer.parseInt(word);
        }
        while (scanner3.hasNext()) {
            word = scanner3.next();
            if (word.equals("Rounds") || word.equals("Won:")) {
                continue;
            }
            m_tournament_scoreboard[1] += Integer.parseInt(word);
        }

        // human
        while (scanner2.hasNext()) {
            word = scanner2.next();
            if (word.equals("Score:")) {
                continue;
            }
            m_scoreboard[0] = Integer.parseInt(word);
        }
        while (scanner4.hasNext()) {
            word = scanner4.next();
            if (word.equals("Rounds") || word.equals("Won:")) {
                continue;
            }
            m_tournament_scoreboard[0] += Integer.parseInt(word);
        }
    }

    public void read_in_turn(String a_temp)
    {
        Scanner scanner = new Scanner(a_temp);
        while (scanner.hasNext()) {
            String word = scanner.next();
            if (word.equals("Turn:")) {
                continue;
            }
            if (word.equals("Human")) {
                m_turn_order[0] = m_human;
                m_turn_order[1] = m_bot;
            } else if (word.equals("Computer")) {
                m_turn_order[0] = m_bot;
                m_turn_order[1] = m_human;
            }
        }
    }

    public void save_game() throws IOException
    {
        //FileWriter out_file = new FileWriter("C:/Users/asus/IdeaProjects/test1/src/OPLsaveFile.txt","UTF-8");
        Writer out_file = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("src/OPLsaveFile.txt"), "UTF-8"));

        //bot write
        out_file.write("Computer:\n");
        out_file.write("   Stacks: ");
        for (int i = 0; i < 6; i++)
        {
            //out_file.write(m_stack.get_stack().get(i).display_color() + m_stack.get_stack().get(i).display_l_pips() + m_stack.get_stack().get(i).display_r_pips() + " ");
            out_file.write(m_stack.get_stack().get(i).display_color() + String.valueOf(m_stack.get_stack().get(i).display_l_pips()) + String.valueOf(m_stack.get_stack().get(i).display_r_pips()) + " ");

        }
        out_file.write("\n");
        out_file.write("   Boneyard: ");
        if (!m_bot.get_boneyard().isEmpty()) {
            for (domino x : m_bot.get_boneyard()) {
                //out_file.write(x.display_color() + x.display_l_pips() + x.display_r_pips() + " ");
                out_file.write(x.display_color() + String.valueOf(x.display_l_pips()) + String.valueOf(x.display_r_pips()) + " ");
            }
        } else {
            out_file.write("");
        }
        out_file.write("\n");
        out_file.write("   Hand: ");
        if (!m_bot.get_hand().isEmpty()) {
            for (domino x : m_bot.get_hand()) {
                //out_file.write(x.display_color() + x.display_l_pips() + x.display_r_pips() + " ");
                out_file.write(x.display_color() + String.valueOf(x.display_l_pips()) + String.valueOf(x.display_r_pips()) + " ");

            }
        } else {
            out_file.write("");
        }
        out_file.write("\n");
        out_file.write("   Score: " + m_scoreboard[1] + "\n");
        out_file.write("   Rounds Won: " + m_tournament_scoreboard[1] + "\n\n");

        //human write
        out_file.write("Human:\n");
        out_file.write("   Stacks: ");
        for (int i = 6; i < 12; i++) {
            //out_file.write(m_stack.get_stack().get(i).display_color() + m_stack.get_stack().get(i).display_l_pips() + m_stack.get_stack().get(i).display_r_pips() + " ");
            out_file.write(m_stack.get_stack().get(i).display_color() + String.valueOf(m_stack.get_stack().get(i).display_l_pips()) + String.valueOf(m_stack.get_stack().get(i).display_r_pips()) + " ");

        }
        out_file.write("\n");
        out_file.write("   Boneyard: ");
        if (!m_human.get_boneyard().isEmpty()) {
            for (domino x : m_human.get_boneyard()) {
                //out_file.write(x.display_color() + x.display_l_pips() + x.display_r_pips() + " ");
                out_file.write(x.display_color() + String.valueOf(x.display_l_pips()) + String.valueOf(x.display_r_pips()) + " ");
            }
        } else {
            out_file.write("");
        }
        out_file.write("\n");
        out_file.write("   Hand: ");
        if (!m_human.get_hand().isEmpty()) {
            for (domino x : m_human.get_hand()) {
                //out_file.write(x.display_color() + x.display_l_pips() + x.display_r_pips() + " ");
                out_file.write(x.display_color() + String.valueOf(x.display_l_pips()) + String.valueOf(x.display_r_pips()) + " ");
            }
        } else {
            out_file.write("");
        }
        out_file.write("\n");
        out_file.write("   Score: " + m_scoreboard[0] + "\n");
        out_file.write("   Rounds Won: " + m_tournament_scoreboard[0] + "\n\n");

        out_file.write("Turn: ");
        if (m_turn_order[m_round.get_turn()].get_id() == 'B') {
            out_file.write("Human");
        } else if (m_turn_order[m_round.get_turn()].get_id() == 'W') {
            out_file.write("Computer");
        } else {
            out_file.write("");
        }

        out_file.close();
    }

}
