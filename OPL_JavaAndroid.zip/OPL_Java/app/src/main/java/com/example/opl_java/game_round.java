package com.example.opl_java;
import android.os.Build;

import java.util.Scanner;
import java.util.Collections;
import java.util.ArrayList;

public class game_round
{
    //turn tracker
    private int m_turn;

    public BuildUpController m_controller;

    public game_round()
    {
        System.out.print("DEBUG: game_round Constructor");
        System.out.print("\n");
        m_turn = 0;
    }

    public void receiveBuildUpController(BuildUpController a_controller)
    {
        System.out.print("\nDEBUG: receiveBuildUpController() \n\n");

        m_controller = a_controller;
    }

    public boolean round_play(player a_human, player a_bot, stack a_stack, player[] a_turn_order, int[] a_scoreboard)
    {
        System.out.print("\nDEBUG: round_play() \n\n");
        if (a_turn_order[0].get_hand().isEmpty() && a_turn_order[1].get_hand().isEmpty())
        {
            a_turn_order[0].draw();
            a_turn_order[1].draw();
        }

        System.out.print("=============================================================================");
        System.out.print("\n");
        System.out.print("TURN: ");
        System.out.print((a_turn_order[m_turn].get_hand()).get(0).display_color());
        System.out.print("\n");
        System.out.print("=============================================================================");
        System.out.print("\n");
        a_bot.display_boneyard();
        a_bot.display_hand();
        a_stack.display_stack();
        a_human.display_hand();
        a_human.display_boneyard();
        System.out.print("=============================================================================");
        System.out.print("\n");

        return false;


    }

    public void first_pick(player a_human, player a_bot, player[] a_turn_order, ArrayList<domino> a_stack)
    {
        System.out.print("first_pick() called ");
        System.out.print("\n");


        while (a_human.get_boneyard().get(0).total_pips() == a_bot.get_boneyard().get(0).total_pips())
        {
            Collections.shuffle(a_human.get_boneyard());
            Collections.shuffle(a_bot.get_boneyard());
            System.out.print("total number pips for both players are the same, shuffle");
            System.out.print("\n");
        }

        if (a_human.get_boneyard().get(0).total_pips() > a_bot.get_boneyard().get(0).total_pips()) // if human has higher total pips count
        {
            a_turn_order[1] = a_bot;
            a_turn_order[0] = a_human;
            System.out.print("the first domino in the player boneyard has a total pip number of : ");
            System.out.print(a_human.get_boneyard().get(0).total_pips());
            System.out.print(" and the bot's first domino in their boneyard has a total of: ");
            System.out.print(a_bot.get_boneyard().get(0).total_pips());
            System.out.print("\n");
            System.out.print("total number of pips for human is greater, human goes first");
            System.out.print("\n");
            return;
        }
        else if (a_human.get_boneyard().get(0).total_pips() < a_bot.get_boneyard().get(0).total_pips()) // if bot has higher total pips count
        {
            a_turn_order[1] = a_human;
            a_turn_order[0] = a_bot;
            System.out.print("the first domino in the player boneyard has a total pip number of : ");
            System.out.print(a_human.get_boneyard().get(0).total_pips());
            System.out.print(" and the bot's first domino in their boneyard has a total of: ");
            System.out.print(a_bot.get_boneyard().get(0).total_pips());
            System.out.print("\n");
            System.out.print("total number of pips for bot is greater, bot goes first");
            System.out.print("\n");
            return;
        }

    }

    public void score(stack a_stack, player[] a_turn_order, int[] a_scoreboard)
    {
        int bot_total = 0;
        int human_total = 0;

        ArrayList<domino> stack_temp = a_stack.get_stack();

        for (int p = 0; p < 2; p++)
        {
            for (int h = 0; h < a_turn_order[p].get_hand().size(); h++)
            {
                if (a_turn_order[p].get_hand().get(h).display_color() == 'B')
                {
                    human_total -= a_turn_order[p].get_hand().get(h).total_pips();
                }
                else if (a_turn_order[p].get_hand().get(h).display_color() == 'W')
                {
                    bot_total -= a_turn_order[p].get_hand().get(h).total_pips();
                }
            }
        }

        for (domino x : stack_temp)
        {
            if (x.display_color() == 'B')
            {
                human_total += x.total_pips();
            }
            else if (x.display_color() == 'W')
            {
                bot_total += x.total_pips();
            }
        }


        a_scoreboard[0] += human_total;
        a_scoreboard[1] += bot_total;



    }

    public final int get_turn()
    {
        return m_turn;
    }







}

