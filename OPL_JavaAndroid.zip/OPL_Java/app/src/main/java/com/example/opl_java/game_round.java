package com.example.opl_java;
import android.os.Build;

import java.util.Scanner;
import java.util.Collections;
import java.util.ArrayList;

public class game_round
{
    //turn tracker
    private int m_turn;

    private tournament m_tournament;

    public BuildUpController m_controller;

    /**
     * constructor: initializes the m_turn to 0
     */
    public game_round()
    {
        System.out.print("DEBUG: game_round Constructor");
        System.out.print("\n");
        m_turn = 0;
    }

    /**
     * receives the BuildUpController object
     * @param a_controller type: BuildUpController, this corresponds to the reference of the controller object
     */
    public void receiveBuildUpController(BuildUpController a_controller)
    {
        System.out.print("\nDEBUG: receiveBuildUpController() \n\n");

        m_controller = a_controller;
    }

    /**
     * receives the tournament object (model)
     * @param a_tournament type: tournament, this corresponds to the reference of the tournament object
     */
    public void receiveTournament(tournament a_tournament)
    {
        System.out.print("\nDEBUG: tournament() \n\n");

        m_tournament = a_tournament;
    }

    /**
     * this changes/updates the value of m_turn
     */
    public void next_turn()
    {
        if (m_turn == 0)
        {
            m_turn = 1;
        }
        else
        {
            m_turn = 0;
        }
    }

    /**
     * handles how the whole process of the round is going to be
     * @param a_human type: player, a reference to the human player
     * @param a_bot type: player, a reference to the bot player
     * @param a_stack type: stack, a reference to the stack object
     * @param a_turn_order type: player array, a reference to the turn order array
     * @param a_scoreboard type: int array, a reference to the round scoreboard array
     */
    public void round_play(player a_human, player a_bot, stack a_stack, player[] a_turn_order, int[] a_scoreboard)
    {
        display_turn(a_turn_order);

        //check if current player has a playable domino
        if (a_turn_order[m_turn].check_playable(a_turn_order[m_turn].get_hand(), a_stack.get_stack()))
        {

            if((a_turn_order[m_turn].get_hand()).get(0).display_color() == 'W')
            {
                a_turn_order[m_turn].player_play(a_stack, a_bot);
                next_turn();
//                this.round_play(a_human,a_bot,a_stack,a_turn_order,a_scoreboard);
                m_tournament.play();
            }
            else if ((a_turn_order[m_turn].get_hand()).get(0).display_color() == 'B')
            {
//                next_turn();
            }

//            a_bot.player_play(a_stack, a_bot);
        }
        else
        {
            m_controller.appendToScrollView("No legal moves. Skip.\n");
//            next_turn();
            if((a_turn_order[m_turn].get_hand()).get(0).display_color() == 'W')
            {
                next_turn();
            }
            else if ((a_turn_order[m_turn].get_hand()).get(0).display_color() == 'B')
            {
                next_turn();
                this.round_play(a_human,a_bot,a_stack,a_turn_order,a_scoreboard);
            }

        }








    }

    /**
     * displays whose turn it is by calling the appendToScrollView function of the controller
     * @param a_turn_order type: player array, corresponds to the array that holds the player objects in a specific order
     */
    public void display_turn(player[] a_turn_order)
    {
        System.out.print("\nDEBUG: round_play() \n\n");

        String message = "TURN: " + (a_turn_order[m_turn].get_hand()).get(0).display_color() + "\n";
        m_controller.appendToScrollView(message);
    }

    /**
     * this decides which player plays first by cross checking the first dominos in their boneyard
     * @param a_human type: player, this is the reference of the human player
     * @param a_bot type: player, this is the reference of the bot player
     * @param a_turn_order type: player array, this is the refernce for the turn order array
     * @param a_stack type: ArrayList, this corresponds to the 12 stacks
     */
    public void first_pick(player a_human, player a_bot, player[] a_turn_order, ArrayList<domino> a_stack)
    {
        System.out.print("first_pick() ");
        System.out.print("\n");
        String message = "";


        while (a_human.get_boneyard().get(0).total_pips() == a_bot.get_boneyard().get(0).total_pips())
        {
            Collections.shuffle(a_human.get_boneyard());
            Collections.shuffle(a_bot.get_boneyard());
            message = "total number pips for both players are the same, shuffle\n";
            m_controller.appendToScrollView(message);
        }

        if (a_human.get_boneyard().get(0).total_pips() > a_bot.get_boneyard().get(0).total_pips()) // if human has higher total pips count
        {
            a_turn_order[1] = a_bot;
            a_turn_order[0] = a_human;
//            System.out.print("the first domino in the player boneyard has a total pip number of : ");
//            System.out.print(a_human.get_boneyard().get(0).total_pips());
//            System.out.print(" and the bot's first domino in their boneyard has a total of: ");
//            System.out.print(a_bot.get_boneyard().get(0).total_pips());
//            System.out.print("\n");
//            System.out.print("total number of pips for human is greater, human goes first");
//            System.out.print("\n");

            message = "The first domino in the player boneyard has a total of : "
                    + a_human.get_boneyard().get(0).total_pips()
                    + "\n"
                    + "The first domino in the bot boneyard has a total of: "
                    + a_bot.get_boneyard().get(0).total_pips()
                    + "\n"
                    + "total number of pips for human is greater, human goes first"
                    + "\n";

            m_controller.appendToScrollView(message);
            return;
        }
        else if (a_human.get_boneyard().get(0).total_pips() < a_bot.get_boneyard().get(0).total_pips()) // if bot has higher total pips count
        {
            a_turn_order[1] = a_human;
            a_turn_order[0] = a_bot;
//            System.out.print("the first domino in the player boneyard has a total pip number of : ");
//            System.out.print(a_human.get_boneyard().get(0).total_pips());
//            System.out.print("  first domino in their boneyard has a total of: ");
//            System.out.print(a_bot.get_boneyard().get(0).total_pips());
//            System.out.print("\n");
//            System.out.print("total number of pips for bot is greater, bot goes first");
//            System.out.print("\n");

            message = "The first domino in the player boneyard has a total of : "
                    + a_human.get_boneyard().get(0).total_pips()
                    + "\n"
                    + "The first domino in the bot boneyard has a total of: "
                    + a_bot.get_boneyard().get(0).total_pips()
                    + "\n"
                    + "total number of pips for bot is greater, bot goes first"
                    + "\n";

            m_controller.appendToScrollView(message);
            return;
        }

    }

    /**
     * responsible for scoring a round
     * @param a_stack type: stack, this corresponds to the reference of the stack object
     * @param a_turn_order type: player array, this is the reference of the turn order array
     * @param a_scoreboard type: int array, this is the reference of the round scoreboard
     */
    public void score(stack a_stack, player[] a_turn_order, int[] a_scoreboard)
    {
        int bot_total = 0;
        int human_total = 0;

        ArrayList<domino> stack_temp = a_stack.get_stack();

        for (int p = 0; p < 2; p++)
        {
            for (int h = 0; h < a_turn_order[p].get_hand().size(); h++)
            {
                if (a_turn_order[p].get_hand().get(h).display_color() == 'B')
                {
                    human_total -= a_turn_order[p].get_hand().get(h).total_pips();
                }
                else if (a_turn_order[p].get_hand().get(h).display_color() == 'W')
                {
                    bot_total -= a_turn_order[p].get_hand().get(h).total_pips();
                }
            }
        }

        for (domino x : stack_temp)
        {
            if (x.display_color() == 'B')
            {
                human_total += x.total_pips();
            }
            else if (x.display_color() == 'W')
            {
                bot_total += x.total_pips();
            }
        }


        a_scoreboard[0] += human_total;
        a_scoreboard[1] += bot_total;



    }

    /**
     * gets the the value of the m_turn
     * @return returns an integer that corresponds the the value of the m_turn
     */
    public final int get_turn()
    {
        return m_turn;
    }







}

