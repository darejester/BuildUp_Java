/*
 ************************************************************
 * Name:  John Matthew Sahagun                              *
 * Project:  Build-Up JAVA version                           *
 * Class:  OPL CMPS366 01                                   *
 * Date:  4/5/2023                                          *
 ************************************************************
 */

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args) throws IOException
    {
        //seed for RNG
        Random random = new Random(System.currentTimeMillis());
        int randInt1 = random.nextInt();
        System.out.println("DEBUG: Random integer1: " + randInt1);
        int randInt2 = random.nextInt();
        System.out.println("DEBUG: Random integer2: " + randInt2);

        //create a tournament object
        tournament game = new tournament();

        //answer variable to decide if resuming or starting a new game
        int answer = -1;
        Scanner input = new Scanner(System.in);


        System.out.print("WELCOME!");
        System.out.print("\n");
        System.out.print("0 - start new tournament, 1 - resume saved tournament");
        System.out.print("\n");
        answer = input.nextInt();
        while (answer < 0 || answer > 1)
        {
            System.out.print("Input invalid. Please try again....");
            System.out.print("\n");
            answer = input.nextInt();
        }

        if (answer == 0)
        {
            System.out.print("DEBUG: startTournament");
            game.start_tournament();
        }
        else if (answer == 1)
        {
            System.out.print("DEBUG: resumeTournament");
            game.resume_tournament();

        }
    }

}
