import java.util.Scanner;
import java.util.ArrayList;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.String;
import java.io.FileWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.Writer;








public class tournament
{
    //stack holder
    private stack m_stack;
    //player holder
    private human m_human;
    private bot m_bot;
    //turn holder
    private player[] m_turn_order;
    //round holder
    private game_round m_round;
    //score board holder(for whole tournament)
    private int[] m_scoreboard = new int[2];;
    // holds number of rounds
    private int m_game_round_counter;
    // holds tournament scoreboard
    private int[] m_tournament_scoreboard = new int[2];

    //constructor
    public tournament() {
        System.out.print("DEBUG: tournament constructor \n");
        m_scoreboard[1] = 0;
        m_game_round_counter = 0;
        m_stack = new stack();
        m_stack.get_stack().clear();
        m_round = null;
        m_bot = new bot();
        m_bot.fill_stack(m_stack.get_stack());
        m_human = new human();
        m_human.fill_stack(m_stack.get_stack());
        m_turn_order = new player[2];
        m_turn_order[0] = null;
        m_turn_order[1] = null;
        m_tournament_scoreboard[0] = 0;
        m_tournament_scoreboard[1] = 0;
    }

    public final tournament get_tournament()
    {
        return this;
    }

    public player get_player()
    {
        return m_human;
    }

    public stack get_stack()
    {
        return m_stack;
    }

    //start tournament
    public void start_tournament() throws IOException
    {
        int continue_game = 1;
        int continued_tournament = 0;
        Scanner input = new Scanner(System.in);

        // game loop
        while (continue_game == 1)
        {
            //initialize new round
            m_round = new game_round();

            //first pick if first round
            if (m_human.get_boneyard().size() == 22)
            {
                m_round.first_pick(m_human, m_bot, m_turn_order, m_stack.get_stack());
            }

            System.out.print("ROUND SCOREBOARD");
            System.out.print("\n");
            System.out.print("B : ");
            System.out.print(m_scoreboard[0]);
            System.out.print("\n");
            System.out.print("W : ");
            System.out.print(m_scoreboard[1]);
            System.out.print("\n");

            System.out.print("TOURNAMENT SCOREBOARD");
            System.out.print("\n");
            System.out.print("B: ");
            System.out.print(m_tournament_scoreboard[0]);
            System.out.print("\n");
            System.out.print("W: ");
            System.out.print(m_tournament_scoreboard[1]);
            System.out.print("\n");

            //play
            if (m_round.round_play(m_human, m_bot, m_stack, m_turn_order, m_scoreboard))
            {
                //save game
                System.out.print("save_game");
                save_game();

                return;
            }
            else
            {
                //continue playing
            }


            //display
            m_bot.display_boneyard();
            m_bot.display_hand();
            m_stack.display_stack();
            m_human.display_hand();
            m_human.display_boneyard();

            //score
            m_round.score(m_stack, m_turn_order, m_scoreboard);



            //clear hands
            for (player x : m_turn_order)
            {
                x.get_hand().clear();
            }

            //continue?
            if (m_human.get_boneyard().isEmpty())
            {
                //update tournament scoreboard
                if (m_scoreboard[0] > m_scoreboard[1])
                {
                    m_tournament_scoreboard[0]++;
                }
                else if (m_scoreboard[0] < m_scoreboard[1])
                {
                    m_tournament_scoreboard[1]++;
                }
                else if (m_scoreboard[0] == m_scoreboard[1])
                {
                    m_tournament_scoreboard[0]++;
                    m_tournament_scoreboard[1]++;
                }

                //B = player, W = bot
                System.out.print("End of Round Scores: ");
                System.out.print("\n");
                System.out.print("B : ");
                System.out.print(m_scoreboard[0]);
                System.out.print("\n");
                System.out.print("W : ");
                System.out.print(m_scoreboard[1]);
                System.out.print("\n");
                System.out.print("Do you want to continue onto the next tournament?");
                System.out.print("\n");
                System.out.print("1 = continue, 0 = exit");
                System.out.print("\n");
                continue_game = input.nextInt();
                while ((continue_game > 1) || (continue_game < 0))
                {
                    System.out.print("input invalid. plase try again...");
                    System.out.print("\n");
                    continue_game = input.nextInt();
                }

                if (continue_game == 1)
                {


                    m_game_round_counter = 0;

                    m_bot = new bot();
                    m_bot.fill_stack(m_stack.get_stack());
                    m_human = new human();
                    m_human.fill_stack(m_stack.get_stack());
                    m_turn_order[0] = null;
                    m_turn_order[1] = null;
                    m_scoreboard[0] = 0;
                    m_scoreboard[1] = 0;
                    continued_tournament = 1;
                    continue;
                }
                else // display winner
                {
                    if ((m_tournament_scoreboard[0] > m_tournament_scoreboard[1]))
                    {
                        System.out.print("WINNER: HUMAN!");
                        System.out.print("\n");
                    }
                    else if (m_tournament_scoreboard[0] < m_tournament_scoreboard[1])
                    {
                        System.out.print("WINNER: BOT!");
                        System.out.print("\n");
                    }
                    else
                    {
                        System.out.print("DRAW!");
                        System.out.print("\n");
                    }

                }
            }

            m_game_round_counter++;
        }
    }

//    public void resume_tournament()
//    {
//        //read from save file
//        //std::cout << "to be implemented" << std::endl;
//        //clear out stack
//        m_stack.get_stack().clear();
//        //clear out player infos
//        m_human.get_hand().clear();
//        m_human.get_boneyard().clear();
//        m_bot.get_hand().clear();
//        m_bot.get_boneyard().clear();
//
//        FileInputStream file = new FileInputStream("OPLsaveFile.txt");
//        ArrayList<String> hand_temp = new ArrayList<String>();
//        ArrayList<String> stack_temp = new ArrayList<String>();
//        ArrayList<String> divided_line = new ArrayList<String>();
//        String line;
//
//
//        if (!file.eof())
//        {
//            //divide line into a vector
//            while (getline(file, line))
//            {
//                divided_line.add(line);
//            }
//            //read in stacks
//            read_to_stack(divided_line.get(1));
//            read_to_stack(divided_line.get(8));
//            //m_stack.display_stack();
//
//            //read in player infos
//            read_to_player(divided_line.get(2), divided_line.get(3), divided_line.get(9), divided_line.get(10));
//
//            //read in scores
//            read_to_score(divided_line.get(4), divided_line.get(11), divided_line.get(5), divided_line.get(12));
//
//            //read in turn
//            read_in_turn(divided_line.get(14));
//
//
//            file.close(); // Close the file when you're done
//
//            //start tournament where it left off
//            start_tournament();
//        }
//        else
//        {
//            System.out.print("Unable to open file");
//            System.out.print("\n");
//        }
//    }

    public void resume_tournament() {
    // read from save file
    // System.out.println("to be implemented");

    // clear out stack
    m_stack.get_stack().clear();

    // clear out player infos
    m_human.get_hand().clear();
    m_human.get_boneyard().clear();
    m_bot.get_hand().clear();
    m_bot.get_boneyard().clear();

    try {
        System.out.println(System.getProperty("user.dir"));
        FileInputStream file = new FileInputStream("src/OPLsaveFile.txt");
        BufferedReader br = new BufferedReader(new InputStreamReader(file));

        ArrayList<String> divided_line = new ArrayList<String>();
        String line;

        // divide line into a vector
        while ((line = br.readLine()) != null) {
            divided_line.add(line);
        }

        // read in stacks
        read_to_stack(divided_line.get(1));
        read_to_stack(divided_line.get(8));

        // read in player infos
        read_to_player(divided_line.get(2), divided_line.get(3), divided_line.get(9), divided_line.get(10));

        // read in scores
        read_to_score(divided_line.get(4), divided_line.get(11), divided_line.get(5), divided_line.get(12));

        // read in turn
        read_in_turn(divided_line.get(14));

        file.close(); // Close the file when you're done

        // start tournament where it left off
        start_tournament();
    } catch (IOException e) {
        System.out.println("Unable to open file");
    }
}

    public void read_to_stack(String a_temp) {
        String[] words = a_temp.split(" ");
        for (String word : words) {
            if (word.equals("Stacks:")) {
                continue;
            }

            if (word.length() >= 3 && Character.isDigit(word.charAt(1)) && Character.isDigit(word.charAt(2))) {
                m_stack.get_stack().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
            }
            else
            {
                // handle error or skip this line
            }
            //m_stack.get_stack().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }
    }

    void read_to_player(String a_temp1, String a_temp2, String a_temp3, String a_temp4) {
        //1 = bot boneyard, 2 = bot hand, 3 = human boneyard, 4 = human hand
        ArrayList<domino> a_temp_hand = new ArrayList<>();
        ArrayList<domino> a_temp_boneyard = new ArrayList<>();
        Scanner iss1 = new Scanner(a_temp1);
        Scanner iss2 = new Scanner(a_temp2);
        Scanner iss3 = new Scanner(a_temp3);
        Scanner iss4 = new Scanner(a_temp4);

        String word;

        //bot
        while (iss1.hasNext()) {
            word = iss1.next();
            if (word.equals("Boneyard:")) {
                continue;
            }
            m_bot.get_boneyard().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }
        while (iss2.hasNext()) {
            word = iss2.next();
            if (word.equals("Hand:")) {
                continue;
            }
            m_bot.get_hand().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }

        //human
        while (iss3.hasNext()) {
            word = iss3.next();
            if (word.equals("Boneyard:")) {
                continue;
            }
            m_human.get_boneyard().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }
        while (iss4.hasNext()) {
            word = iss4.next();
            if (word.equals("Hand:")) {
                continue;
            }
            m_human.get_hand().add(new domino(Character.getNumericValue(word.charAt(1)), Character.getNumericValue(word.charAt(2)), word.charAt(0)));
        }
    }

    public void read_to_score(String a_temp1, String a_temp2, String a_temp3, String a_temp4) {
        Scanner scanner1 = new Scanner(a_temp1);
        Scanner scanner2 = new Scanner(a_temp2);
        Scanner scanner3 = new Scanner(a_temp3);
        Scanner scanner4 = new Scanner(a_temp4);

        String word;
        // bot
        while (scanner1.hasNext()) {
            word = scanner1.next();
            if (word.equals("Score:")) {
                continue;
            }
            m_scoreboard[1] = Integer.parseInt(word);
        }
        while (scanner3.hasNext()) {
            word = scanner3.next();
            if (word.equals("Rounds") || word.equals("Won:")) {
                continue;
            }
            m_tournament_scoreboard[1] += Integer.parseInt(word);
        }

        // human
        while (scanner2.hasNext()) {
            word = scanner2.next();
            if (word.equals("Score:")) {
                continue;
            }
            m_scoreboard[0] = Integer.parseInt(word);
        }
        while (scanner4.hasNext()) {
            word = scanner4.next();
            if (word.equals("Rounds") || word.equals("Won:")) {
                continue;
            }
            m_tournament_scoreboard[0] += Integer.parseInt(word);
        }
    }

    public void read_in_turn(String a_temp)
    {
        Scanner scanner = new Scanner(a_temp);
        while (scanner.hasNext()) {
            String word = scanner.next();
            if (word.equals("Turn:")) {
                continue;
            }
            if (word.equals("Human")) {
                m_turn_order[0] = m_human;
                m_turn_order[1] = m_bot;
            } else if (word.equals("Computer")) {
                m_turn_order[0] = m_bot;
                m_turn_order[1] = m_human;
            }
        }
    }

    public void save_game() throws IOException
    {
        //FileWriter out_file = new FileWriter("C:/Users/asus/IdeaProjects/test1/src/OPLsaveFile.txt","UTF-8");
        Writer out_file = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("src/OPLsaveFile.txt"), "UTF-8"));

        //bot write
        out_file.write("Computer:\n");
        out_file.write("   Stacks: ");
        for (int i = 0; i < 6; i++)
        {
            //out_file.write(m_stack.get_stack().get(i).display_color() + m_stack.get_stack().get(i).display_l_pips() + m_stack.get_stack().get(i).display_r_pips() + " ");
            out_file.write(m_stack.get_stack().get(i).display_color() + String.valueOf(m_stack.get_stack().get(i).display_l_pips()) + String.valueOf(m_stack.get_stack().get(i).display_r_pips()) + " ");

        }
        out_file.write("\n");
        out_file.write("   Boneyard: ");
        if (!m_bot.get_boneyard().isEmpty()) {
            for (domino x : m_bot.get_boneyard()) {
                //out_file.write(x.display_color() + x.display_l_pips() + x.display_r_pips() + " ");
                out_file.write(x.display_color() + String.valueOf(x.display_l_pips()) + String.valueOf(x.display_r_pips()) + " ");
            }
        } else {
            out_file.write("");
        }
        out_file.write("\n");
        out_file.write("   Hand: ");
        if (!m_bot.get_hand().isEmpty()) {
            for (domino x : m_bot.get_hand()) {
                //out_file.write(x.display_color() + x.display_l_pips() + x.display_r_pips() + " ");
                out_file.write(x.display_color() + String.valueOf(x.display_l_pips()) + String.valueOf(x.display_r_pips()) + " ");

            }
        } else {
            out_file.write("");
        }
        out_file.write("\n");
        out_file.write("   Score: " + m_scoreboard[1] + "\n");
        out_file.write("   Rounds Won: " + m_tournament_scoreboard[1] + "\n\n");

        //human write
        out_file.write("Human:\n");
        out_file.write("   Stacks: ");
        for (int i = 6; i < 12; i++) {
            //out_file.write(m_stack.get_stack().get(i).display_color() + m_stack.get_stack().get(i).display_l_pips() + m_stack.get_stack().get(i).display_r_pips() + " ");
            out_file.write(m_stack.get_stack().get(i).display_color() + String.valueOf(m_stack.get_stack().get(i).display_l_pips()) + String.valueOf(m_stack.get_stack().get(i).display_r_pips()) + " ");

        }
        out_file.write("\n");
        out_file.write("   Boneyard: ");
        if (!m_human.get_boneyard().isEmpty()) {
            for (domino x : m_human.get_boneyard()) {
                //out_file.write(x.display_color() + x.display_l_pips() + x.display_r_pips() + " ");
                out_file.write(x.display_color() + String.valueOf(x.display_l_pips()) + String.valueOf(x.display_r_pips()) + " ");
            }
        } else {
            out_file.write("");
        }
        out_file.write("\n");
        out_file.write("   Hand: ");
        if (!m_human.get_hand().isEmpty()) {
            for (domino x : m_human.get_hand()) {
                //out_file.write(x.display_color() + x.display_l_pips() + x.display_r_pips() + " ");
                out_file.write(x.display_color() + String.valueOf(x.display_l_pips()) + String.valueOf(x.display_r_pips()) + " ");
            }
        } else {
            out_file.write("");
        }
        out_file.write("\n");
        out_file.write("   Score: " + m_scoreboard[0] + "\n");
        out_file.write("   Rounds Won: " + m_tournament_scoreboard[0] + "\n\n");

        out_file.write("Turn: ");
        if (m_turn_order[m_round.get_turn()].get_id() == 'B') {
            out_file.write("Human");
        } else if (m_turn_order[m_round.get_turn()].get_id() == 'W') {
            out_file.write("Computer");
        } else {
            out_file.write("");
        }

        out_file.close();
    }






    }
