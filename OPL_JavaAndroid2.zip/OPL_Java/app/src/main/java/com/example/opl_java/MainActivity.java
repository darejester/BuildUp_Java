package com.example.opl_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.Toast;
import android.content.Intent;
import java.io.IOException;


import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity{
    public Button m_resumeButton;
    public  Button m_startButton;

    //model
    public tournament m_tournament;

    public MainController m_controller;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //start button
        m_startButton = findViewById(R.id.startButton);
        //resume button
        m_resumeButton = findViewById(R.id.resumeButton);


        m_controller = new MainController(this);




        //on startButton click
        m_startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "DEBUG: START BUTTON", Toast.LENGTH_SHORT).show();


                //move to another activity
                System.out.print("\nDEBUG: MainActivity Intent created \n\n");
                Intent intent = new Intent(MainActivity.this, PlayActivity.class);


                System.out.print("\nDEBUG: Adding tournament to Intent \n\n");
                intent.putExtra("model", m_controller.controller_start_tournament());

                System.out.print("\nDEBUG:  MainActivity Intent passed to PlayActivity \n\n");
                startActivity(intent);
            }
        });

        //on resumeButton click
        m_resumeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "DEBUG: RESUME BUTTON", Toast.LENGTH_SHORT).show();

                //move to another activity
                System.out.print("\nDEBUG: MainActivity Intent created \n\n");
                Intent intent = new Intent(MainActivity.this, PlayActivity.class);

                System.out.print("\nDEBUG: Adding tournament to Intent \n\n");
                intent.putExtra("model", m_controller.controller_resume_tournament());

                System.out.print("\nDEBUG:  MainActivity Intent passed to PlayActivity \n\n");
                startActivity(intent);


            }
        });


    }
}