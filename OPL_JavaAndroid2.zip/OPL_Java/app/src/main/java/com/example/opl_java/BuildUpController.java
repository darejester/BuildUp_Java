package com.example.opl_java;

import java.io.IOException;
import android.widget.Button;
import android.view.View;
import java.util.ArrayList;

public class BuildUpController {
    //model
//    private BuildUpModel m_model;
    private tournament m_tournament;
    //view
    private PlayActivity m_playActivity;



    //constructor
    public BuildUpController(tournament a_tournament ,PlayActivity a_playActivity)
    {
        System.out.print("\nDEBUG: BuildUpController Constructor \n\n");

        //set view
        System.out.print("\nDEBUG: getting PlayActivity reference \n\n");
        m_playActivity = a_playActivity;
        System.out.print("\nDEBUG: getting tournament reference \n\n");
        m_tournament = a_tournament;

        System.out.print("\nDEBUG: give tournament the BuildUpController Reference \n\n");
        try
        {

            m_tournament.receiveBuildUpController(this);
        }
        catch (IOException e)
        {
            // Handle the exception here
            System.out.print("\nDEBUG: IOException \n\n");
        }

        System.out.print("\nDEBUG: choose if resuming or starting new \n\n");
        if(m_tournament.m_resumeOrStart == 0)
        {
            try
            {
                m_playActivity.m_messageWindow.append("DEBUG: start_tournament() \n");
                m_tournament.start_tournament();
            }
            catch (IOException e)
            {
                // Handle the exception here
                System.out.print("\nDEBUG: IOException \n\n");
            }
        }
        else if (m_tournament.m_resumeOrStart == 1)
        {
            m_playActivity.m_messageWindow.append("DEBUG: resume_tournament() \n");
            m_tournament.resume_tournament();
        }

    }



    //gets result from model and display it in the message window of view
    public void appendToScrollView(String test)
    {
        //messageWindow.append(String.valueOf(testInt));
        m_playActivity.m_messageWindow.append(String.valueOf(test));
    }

    public void updateBotBone(ArrayList<domino> a_BotBone)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.botBone.length; i++)
        {
            if (i < a_BotBone.size())
            {
                m_playActivity.botBone[i].setText(String.valueOf(a_BotBone.get(i).display_l_pips()) + "\n" + a_BotBone.get(i).display_r_pips());
                m_playActivity.botBone[i].setVisibility(View.VISIBLE);
            }
            else
            {
                m_playActivity.botBone[i].setText("");
                m_playActivity.botBone[i].setVisibility(View.INVISIBLE);
            }

        }
    }

    public void updateBotHand(ArrayList<domino> a_BotHand)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.botHand.length; i++)
        {
            if (i < a_BotHand.size())
            {
                m_playActivity.botHand[i].setText(String.valueOf(a_BotHand.get(i).display_l_pips()) + "\n" + a_BotHand.get(i).display_r_pips());
                m_playActivity.botHand[i].setVisibility(View.VISIBLE);
            }
            else
            {
                m_playActivity.botHand[i].setText("");
                m_playActivity.botHand[i].setVisibility(View.INVISIBLE);
            }

        }
    }

    public void updateStack(ArrayList<domino> a_Stack)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.stack.length; i++)
        {
            if (i < a_Stack.size())
            {
                m_playActivity.stack[i].setText(String.valueOf(a_Stack.get(i).display_l_pips()) + "\n" + a_Stack.get(i).display_r_pips());
                m_playActivity.stack[i].setVisibility(View.VISIBLE);
            }
            else
            {
                m_playActivity.stack[i].setText("");
                m_playActivity.stack[i].setVisibility(View.INVISIBLE);
            }

        }
    }

    public void updateHumanHand(ArrayList<domino> a_HumanHand)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.humanHand.length; i++)
        {
            if (i < a_HumanHand.size())
            {
                m_playActivity.humanHand[i].setText(String.valueOf(a_HumanHand.get(i).display_l_pips()) + "\n" + a_HumanHand.get(i).display_r_pips());
                m_playActivity.humanHand[i].setVisibility(View.VISIBLE);
            }
            else
            {
                m_playActivity.humanHand[i].setText("");
                m_playActivity.humanHand[i].setVisibility(View.INVISIBLE);
            }

        }
    }

    public void updateHumanBone(ArrayList<domino> a_HumanBone)
    {
        //messageWindow.append(String.valueOf(testInt));
        for (int i = 0; i < m_playActivity.humanBone.length; i++)
        {
            if (i < a_HumanBone.size())
            {
                m_playActivity.humanBone[i].setText(String.valueOf(a_HumanBone.get(i).display_l_pips()) + "\n" + a_HumanBone.get(i).display_r_pips());
                m_playActivity.humanBone[i].setVisibility(View.VISIBLE);
            }
            else
            {
                m_playActivity.humanBone[i].setText("");
                m_playActivity.humanBone[i].setVisibility(View.INVISIBLE);
            }

        }
    }

}
