package com.example.opl_java;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class human extends player implements Serializable
{
    private ArrayList<domino> m_hand = new ArrayList<domino>();
    private ArrayList<domino> m_boneyard = new ArrayList<domino>();


    public BuildUpController m_controller;

    public human()
    {
        System.out.print("\nDEBUG: human constructor \n\n");
        for (int l = 0; l <= 6; l++)
        {
            for (int r = l; r <= 6; r++)
            {
                m_boneyard.add(new domino(l, r, 'B'));
            }

            //m_boneyard.push_back(new domino('W'));

        }

        Collections.shuffle(m_boneyard);

        System.out.print("human object created");
        System.out.print("\n");
    }

    public human(ArrayList<domino> a_temp_hand, ArrayList<domino> a_temp_boneyard)
    {
        this.m_hand = new ArrayList<domino>(a_temp_hand);
        this.m_boneyard = new ArrayList<domino>(a_temp_boneyard);
    }

    public void receiveBuildUpController(BuildUpController a_controller)
    {
        System.out.print("\nDEBUG: receiveBuildUpController() \n\n");

        m_controller = a_controller;
    }

    @Override
    public ArrayList<domino> get_hand()
    {
        return this.m_hand;
    }

    @Override
    public ArrayList<domino> get_boneyard()
    {
        return this.m_boneyard;
    }

    @Override
    public char get_id()
    {
        return 'B';
    }

    @Override
    public void draw()
    {
        for (int i = 0; i < 6; i++)
        {
            //for last iteration where dominos are less than 6
            if (m_boneyard.isEmpty())
            {
                break;
            }

            m_hand.add(m_boneyard.get(0));
            //erase
            m_boneyard.remove(0);



        }

    }

    @Override
    public boolean is_hand_empty()
    {
        return m_hand.isEmpty();
    }

    @Override
    public void display_hand()
    {
        System.out.print("PLAYER HAND:");
        System.out.print("\n");
        for (domino x : m_hand)
        {
            x.display_domino();
            System.out.print(" ");
        }
        System.out.print("\n");
        System.out.print(" 0   1   2   3   4   5");
        System.out.print("\n \n");

        m_controller.updateHumanHand(m_hand);

//        String string = "";
//
//        return string;
    }

    @Override
    public void display_boneyard()
    {
//        String string = "";
        System.out.print("PLAYER BONEYARD:");
        System.out.print("\n");
        System.out.print("TOP ");
        for (domino x : m_boneyard)
        {
            x.display_domino();
            System.out.print(" ");
        }
        System.out.print("BOTTOM");
        System.out.print("\n \n");

        m_controller.updateHumanBone(m_boneyard);

//        return string;
    }

    @Override
    public boolean check_legality(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp, int a_loc1, int a_loc2)
    {
        //check if placement of domino is legal
        //condition 1
        //condition 2
        //condition 3
        if ((a_hand.get(a_loc1).display_l_pips() != a_hand.get(a_loc1).display_r_pips()) && (a_hand.get(a_loc1).total_pips() >= a_stack_temp.get(a_loc2).total_pips()))
        {
            //place
            return true;

        }
        else if ((a_hand.get(a_loc1).display_l_pips() == a_hand.get(a_loc1).display_r_pips()) && (a_stack_temp.get(a_loc2).display_l_pips() != a_stack_temp.get(a_loc2).display_r_pips()))
        {
            return true;
        }
        else if ((a_hand.get(a_loc1).display_l_pips() == a_hand.get(a_loc1).display_r_pips()) && (a_stack_temp.get(a_loc2).display_l_pips() == a_stack_temp.get(a_loc2).display_r_pips()) && (a_hand.get(a_loc1).total_pips() > a_stack_temp.get(a_loc2).total_pips()))
        {
            return true;
        }
        else
        {
            System.out.print("Tile placement is illegal.");
            System.out.print("\n");
            System.out.print("A non-double tile may be placed on any tile as long as the total number of pips on it is greater than or equal to that of the tile on which it is placed.");
            System.out.print("\n");
            System.out.print("A double tile (e.g., 0-0, 1-1, 2-2) may be placed on any non-double tile, even if the non-double tile has more pips.");
            System.out.print("\n");
            System.out.print("A double tile may be placed on another double tile only if it has more total pips than the tile on which it is placed.");
            System.out.print("\n");
            return false;
        }
    }

    @Override
    public void place(stack a_stack)
    {

        int loc1;
        int loc2;
        Scanner input = new Scanner(System.in);
        ArrayList<domino> temp = a_stack.get_stack();
//        Iterator<domino> it;
        if (this.check_playable(m_hand, temp))
        {
            //get locations
            System.out.print("which domino do you want to place?");
            System.out.print("\n");
            loc1 = input.nextInt();
            //input validation
            while (loc1 >= m_hand.size() || loc1 < 0)
            {
                System.out.print("There is no domino in that part of your hand. Enter again...");
                System.out.print("\n");
                loc1 = input.nextInt();
            }
            System.out.print("where to place it?");
            System.out.print("\n");
            loc2 = input.nextInt();
            while (loc2 >= 12 || loc2 < 0)
            {
                System.out.print("Invalid location. Enter again...");
                System.out.print("\n");
                loc2 = input.nextInt();
            }

            //check if placement of domino is legal
            //condition 1
            if (this.check_legality(m_hand, temp, loc1, loc2))
            {
                temp.set(loc2, m_hand.get(loc1));
                m_hand.remove(loc1);
                return;
            }
        }



    }

    @Override
    public void fill_stack(ArrayList<domino> a_stack)
    {
        for (int i = 6; i < 12; i++)
        {
            //m_hand.push_back(*m_boneyard.begin());
            a_stack.add(i, m_boneyard.get(0));
            //erase
            m_boneyard.remove(0);

        }
    }

    public void get_help(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp,  int[] a_loc1, int[] a_loc2, player a_bot)
    {
        int ans = -1;
        Scanner input = new Scanner(System.in);
//        Iterator<domino> it;

        a_bot.strategy(a_hand, a_stack_temp, a_loc1, a_loc2);

        System.out.print("Do you want to play this move?");
        System.out.print("\n");
        System.out.print("1= yes, 0 = no");
        System.out.print("\n");
        ans = input.nextInt();
        while (ans > 1 || ans < 0)
        {
            System.out.print("Input invalid. pleas try again...");
            System.out.print("\n");
            ans = input.nextInt();
        }
        if (ans == 1)
        {
            //place
            a_stack_temp.set(a_loc2[0], a_hand.get(a_loc1[0]));
            a_hand.remove(a_loc1[0]);
        }
        else
        {
            return;
        }
    }

    @Override
    public final void player_play(stack a_stack, player a_bot)
    {
//        int loc1 = 0;
//        int loc2 = 0;
        int[] loc1 = new int[1];
        int[] loc2 = new int[1];
        int action = -1;
        Scanner input = new Scanner(System.in);

        //action input
        System.out.print("ACTIONS:");
        System.out.print("\n");
        System.out.print("1-Place card, 2-Ask Bot for Help,....");
        System.out.print("\n");
        action = input.nextInt();
        while (action > 2 || action <= 0)
        {
            System.out.print("INPUT INVALID. Try again....");
            System.out.print("\n");
            action = input.nextInt();
        }
        //action decider
        if (action == 1)
        {
            this.place(a_stack);
        }
        else if (action == 2)
        {
            this.get_help(m_hand, a_stack.get_stack(), loc1, loc2, a_bot);
        }



    }

    @Override
    public final boolean check_playable(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp)
    {
        // check if there is/are any plable domino(s)
        for (domino t : a_stack_temp)
        {
            for (domino h : a_hand)
            {
                //check if placement of domino is legal
                //condition 1
                //condition 2
                //condition 3
                if ((h.display_l_pips() != h.display_r_pips()) && (h.total_pips() >= t.total_pips()))
                {
                    return true;


                }
                else if ((h.display_l_pips() == h.display_r_pips()) && (t.display_l_pips() != t.display_r_pips()))
                {

                    return true;
                }
                else if ((h.display_l_pips() == h.display_r_pips()) && (t.display_l_pips() == t.display_r_pips()) && (h.total_pips() > t.total_pips()))
                {

                    return true;
                }
            }
        }
        //if no more playable domino(s)
        System.out.print("No more playable domino(s)");
        System.out.print("\n");
        return false;
    }


    @Override
    public final void strategy(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp, int[] a_loc1, int[] a_loc2)
    {
    }






}

