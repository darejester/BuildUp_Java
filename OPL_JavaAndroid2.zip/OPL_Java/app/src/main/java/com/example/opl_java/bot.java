package com.example.opl_java;
import java.util.ArrayList;
import java.util.Collections;
import java.io.Serializable;

public class bot extends player implements Serializable
{
    private ArrayList<domino> m_hand = new ArrayList<domino>();
    private ArrayList<domino> m_boneyard = new ArrayList<domino>();

    public BuildUpController m_controller;

    public bot()
    {
        System.out.print("\nDEBUG: bot constructor \n\n");
        for (int l = 0; l <= 6; l++)
        {
            for (int r = l; r <= 6; r++)
            {
                m_boneyard.add(new domino(l, r, 'W'));
            }

            //m_boneyard.push_back(new domino('B'));

        }

        Collections.shuffle(m_boneyard);

        System.out.print("bot object created");
        System.out.print("\n");
    }

    public bot(ArrayList<domino> a_temp_hand, ArrayList<domino> a_temp_boneyard)
    {
        this.m_hand = new ArrayList<domino>(a_temp_hand);
        this.m_boneyard = new ArrayList<domino>(a_temp_boneyard);
    }

    public void receiveBuildUpController(BuildUpController a_controller)
    {
        System.out.print("\nDEBUG: receiveBuildUpController() \n\n");

        m_controller = a_controller;
    }

    @Override
    public ArrayList<domino> get_hand()
    {
        return this.m_hand;
    }

    @Override
    public ArrayList<domino> get_boneyard()
    {

        return this.m_boneyard;
    }

    @Override
    public final char get_id()
    {
        return 'W';
    }

    @Override
    public void draw()
    {
        for (int i = 0; i < 6; i++)
        {
            //for last iteration where dominos are less than 6
            if (m_boneyard.isEmpty())
            {
                break;
            }

            m_hand.add(m_boneyard.get(0));
            //erase
            m_boneyard.remove(0);



        }

    }

    @Override
    public boolean is_hand_empty()
    {
        return m_hand.isEmpty();
    }

    @Override
    public void display_hand()
    {
        System.out.print("BOT HAND:");
        System.out.print("\n");
        for (domino y : m_hand)
        {
            y.display_domino();
            System.out.print(" ");
        }
        System.out.print("\n");
        System.out.print(" 0   1   2   3   4   5");
        System.out.print("\n \n");

        m_controller.updateBotHand(m_hand);

//        String string = "";
//        string += "BOT HAND: ";
//        for (domino x : m_hand)
//        {
//            x.display_domino();
//            string += x;
//        }
//        string += "\n";
//        string +=  "0   1   2   3   4   5\n\n";
//
//
//        return string;

    }

    @Override
    public void display_boneyard()
    {
        System.out.print("BOT BONEYARD:");
        System.out.print("\n");
        System.out.print("TOP ");
        for (domino x : m_boneyard)
        {
            x.display_domino();
            System.out.print(" ");
        }
        System.out.print("BOTTOM");
        System.out.print("\n \n");

        m_controller.updateBotBone(m_boneyard);



//        String string = "";
//        string += "BOT BONEYARD: \n";
//        string += "TOP ";
//        for (domino x : m_boneyard)
//        {
//            string +=x.display_domino() + " ";
//        }
//        string += " BOTTOM";
//
//
//        return string;
    }

    @Override
    public boolean check_legality(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp, int a_loc1, int a_loc2)
    {
        //check if placement of domino is legal
        //condition 1
        //condition 2
        //condition 3
        if ((a_hand.get(a_loc1).display_l_pips() != a_hand.get(a_loc1).display_r_pips()) && (a_hand.get(a_loc1).total_pips() >= a_stack_temp.get(a_loc2).total_pips()))
        {
            //place
            return true;

        }
        else if ((a_hand.get(a_loc1).display_l_pips() == a_hand.get(a_loc1).display_r_pips()) && (a_stack_temp.get(a_loc2).display_l_pips() != a_stack_temp.get(a_loc2).display_r_pips()))
        {
            return true;
        }
        else if ((a_hand.get(a_loc1).display_l_pips() == a_hand.get(a_loc1).display_r_pips()) && (a_stack_temp.get(a_loc2).display_l_pips() == a_stack_temp.get(a_loc2).display_r_pips()) && (a_hand.get(a_loc1).total_pips() > a_stack_temp.get(a_loc2).total_pips()))
        {
            return true;
        }
        else
        {
            //System.out.print("Tile placement is illegal.");
            //System.out.print("\n");
            //System.out.print("A non-double tile may be placed on any tile as long as the total number of pips on it is greater than or equal to that of the tile on which it is placed.");
            //System.out.print("\n");
            //System.out.print("A double tile (e.g., 0-0, 1-1, 2-2) may be placed on any non-double tile, even if the non-double tile has more pips.");
            //System.out.print("\n");
            //System.out.print("A double tile may be placed on another double tile only if it has more total pips than the tile on which it is placed.");
            //System.out.print("\n");
            return false;
        }
    }

    @Override
    public final void place(stack a_stack)
    {

//        int loc1 = 0;
//        int loc2 = 0;
        int[] loc1 = new int[1];
        int[] loc2 = new int[1];
        ArrayList<domino> temp = a_stack.get_stack();

        this.strategy(m_hand, temp, loc1, loc2);

        //check if placement of domino is legal
        //condition 1
        if (this.check_legality(m_hand, temp, loc1[0], loc2[0]))
        {
            temp.set(loc2[0], m_hand.get(loc1[0]));
            m_hand.remove(loc1[0]);
            return;
        }

    }

    @Override
    public void fill_stack(ArrayList<domino> a_stack)
    {
        for (int i = 0; i < 6; i++)
        {
            //m_hand.push_back(*m_boneyard.begin());
            a_stack.add(i, m_boneyard.get(0));
            //erase
            m_boneyard.remove(0);

        }
    }

    @Override
    public final void player_play(stack a_stack, player a_bot)
    {
        System.out.print("bot playing");
        System.out.print("\n");
        this.place(a_stack);
    }

    @Override
    public final boolean check_playable(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp)
    {
        // check if there is/are any plable domino(s)
        for (domino t : a_stack_temp)
        {
            for (domino h : a_hand)
            {
                //check if placement of domino is legal
                //condition 1
                //condition 2
                //condition 3
                if ((h.display_l_pips() != h.display_r_pips()) && (h.total_pips() >= t.total_pips()))
                {
                    return true;


                }
                else if ((h.display_l_pips() == h.display_r_pips()) && (t.display_l_pips() != t.display_r_pips()))
                {

                    return true;
                }
                else if ((h.display_l_pips() == h.display_r_pips()) && (t.display_l_pips() == t.display_r_pips()) && (h.total_pips() > t.total_pips()))
                {

                    return true;
                }
            }
        }
        //if no more playable domino(s)
        System.out.print("No more playable domino(s)");
        System.out.print("\n");
        return false;
    }

    @Override
    public final void strategy(ArrayList<domino> a_hand, ArrayList<domino> a_stack_temp, int[] a_loc1, int[] a_loc2)
    {
        int h = 0;
        int s = 0;
        while (h < a_hand.size())
        {

            //check best strategic move
            //place higher tile on enemy tile
            while (s < a_stack_temp.size())
            {
                if ((a_stack_temp.get(s).display_color() != a_hand.get(h).display_color()) && (a_stack_temp.get(s).total_pips() < a_hand.get(h).total_pips()))
                {

                    if (this.check_legality(a_hand, a_stack_temp, h, s))
                    {
                        System.out.print("Cover opponent's high tile with own higher tile");
                        System.out.print("\n");
                        System.out.print(h);
                        System.out.print(" in hand to ");
                        System.out.print(s);
                        System.out.print(" of stack");
                        System.out.print("\n");
                        a_loc1[0] = h;
                        a_loc2[0] = s;
                        return;
                    }
                }
                s++;
            }
            s = 0;
            h++;
        }
        s = 0;
        h = 0;

        //place low-value double on high value tile of enemy
        while (h < a_hand.size())
        {
            while (s < a_stack_temp.size())
            {
                if ((a_stack_temp.get(s).display_color() != a_hand.get(h).display_color()) && (a_hand.get(h).display_l_pips() == a_hand.get(h).display_r_pips()) && (a_hand.get(h).total_pips() < a_stack_temp.get(s).total_pips()))
                {
                    if (this.check_legality(a_hand, a_stack_temp, h, s))
                    {
                        System.out.print("Cover opponent's high tile with own lower double tile");
                        System.out.print("\n");
                        System.out.print(h);
                        System.out.print(" in hand to ");
                        System.out.print(s);
                        System.out.print(" of stack");
                        System.out.print("\n");
                        a_loc1[0] = h;
                        a_loc2[0] = s;
                        return;
                    }
                }
                s++;
            }
            s = 0;
            h++;
        }
        s = 0;
        h = 0;

        //place playable tile on own tile
        while (h < a_hand.size())
        {
            while (s < a_stack_temp.size())
            {
                if ((a_stack_temp.get(s).display_color() == a_hand.get(h).display_color()))
                {
                    if (this.check_legality(a_hand, a_stack_temp, h, s))
                    {
                        System.out.print("Cover own tile to avoid having points deducted");
                        System.out.print("\n");
                        System.out.print(h);
                        System.out.print(" in hand to ");
                        System.out.print(s);
                        System.out.print(" of stack");
                        System.out.print("\n");
                        a_loc1[0] = h;
                        a_loc2[0] = s;
                        return;

                    }
                }
                s++;
            }
            s = 0;
            h++;
        }
        s = 0;
        h = 0;
        while (h < a_hand.size())
        {
            while (s < a_stack_temp.size())
            {
                if (this.check_legality(a_hand, a_stack_temp, h, s))
                {
                    System.out.print("No good moves. Just do a legal move");
                    System.out.print("\n");
                    System.out.print(h);
                    System.out.print(" in hand to ");
                    System.out.print(s);
                    System.out.print(" of stack");
                    System.out.print("\n");
                    a_loc1[0] = h;
                    a_loc2[0] = s;
                    return;

                }
                s++;
            }
            s = 0;
        }

    }







}

